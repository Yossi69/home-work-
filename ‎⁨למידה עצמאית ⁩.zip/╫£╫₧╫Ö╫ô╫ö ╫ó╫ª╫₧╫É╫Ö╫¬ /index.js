let allprice = 0;
function burger() {
  allprice = allprice + 5;
  let answer1 = prompt("do you want vegetables inside?");
  let answer2 = prompt("extra petty?");
  let answer3 = prompt("on top?");
  let answer4 = prompt("on the side?");
  let answer5 = prompt("to drink?");

  alert(
    "Your order is:" +
      "veg inside" +
      answer1 +
      "extra petty" +
      answer2 +
      "on top" +
      answer3 +
      "on side" +
      answer4 +
      "to drink:" +
      answer5
  );
}

function pizza() {
  allprice = allprice + 3;
}
function cart() {
  alert(allprice);
}
